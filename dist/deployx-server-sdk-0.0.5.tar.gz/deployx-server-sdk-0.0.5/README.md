# Example Package


DeployX package for using deploy-x.com project
To participate in development you can in [Github](https://github.com/CaptainKryuk/deployx-server-sdk)